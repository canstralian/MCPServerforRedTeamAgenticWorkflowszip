import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { z } from 'zod';
import { v4 as uuidv4 } from 'uuid';
import { store } from '../store/index.js';
import { Agent, AgentType, AgentStatus } from '../types/index.js';
import { logger } from '../utils/logger.js';

export function registerAgentTools(server: Server): void {
  server.setRequestHandler('tools/call', async (request) => {
    const { name, arguments: args } = request.params;

    switch (name) {
      case 'create_agent':
        return handleCreateAgent(args);
      case 'list_agents':
        return handleListAgents(args);
      case 'get_agent':
        return handleGetAgent(args);
      case 'update_agent':
        return handleUpdateAgent(args);
      case 'delete_agent':
        return handleDeleteAgent(args);
      default:
        return { content: [{ type: 'text', text: 'Unknown tool' }] };
    }
  });

  server.setRequestHandler('tools/list', async () => {
    return {
      tools: [
        {
          name: 'create_agent',
          description: 'Create a new red team agent with specified capabilities',
          inputSchema: {
            type: 'object',
            properties: {
              name: { type: 'string', description: 'Agent name' },
              type: {
                type: 'string',
                enum: Object.values(AgentType),
                description: 'Agent type',
              },
              capabilities: {
                type: 'array',
                items: { type: 'string' },
                description: 'List of agent capabilities',
              },
            },
            required: ['name', 'type', 'capabilities'],
          },
        },
        {
          name: 'list_agents',
          description: 'List all registered agents',
          inputSchema: {
            type: 'object',
            properties: {
              status: {
                type: 'string',
                enum: Object.values(AgentStatus),
                description: 'Filter by agent status',
              },
            },
          },
        },
        {
          name: 'get_agent',
          description: 'Get detailed information about a specific agent',
          inputSchema: {
            type: 'object',
            properties: {
              agentId: { type: '